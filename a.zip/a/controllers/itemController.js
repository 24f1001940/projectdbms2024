const { Canteen, Item } = require('../models');
exports.listCanteens = async (req,res) => {
  const list = await Canteen.findAll();
  res.json(list);
};
exports.menuByCanteen = async (req,res) => {
  const id = req.params.id;
  const items = await Item.findAll({ where: { canteen_id: id, is_active: true }});
  res.json(items);
};
