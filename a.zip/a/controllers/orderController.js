const { sequelize } = require('../config/db');
const { Order, OrderItem, Item } = require('../models');

exports.createOrder = async (req,res) => {
  const { items, canteen_id } = req.body; // items: [{ item_id, quantity }]
  if (!items || !Array.isArray(items) || items.length === 0) return res.status(400).json({ message: 'No items' });

  const t = await sequelize.transaction();
  try {
    let total = 0;
    // lock rows and check stock
    for (const it of items) {
      const row = await Item.findByPk(it.item_id, { transaction: t, lock: t.LOCK.UPDATE });
      if (!row || !row.is_active) throw new Error(`Item ${it.item_id} unavailable`);
      if (row.stock < it.quantity) throw new Error(`Insufficient stock for ${row.name}`);
      // decrement
      row.stock = row.stock - it.quantity;
      await row.save({ transaction: t });
      total += parseFloat(row.price) * it.quantity;
    }

    const order = await Order.create({
      user_id: req.user.id,
      total,
      status: 'placed',
      canteen_id
    }, { transaction: t });

    for (const it of items) {
      const itemData = await Item.findByPk(it.item_id, { transaction: t });
      await OrderItem.create({
        order_id: order.id,
        item_id: it.item_id,
        quantity: it.quantity,
        price_at_order: itemData.price
      }, { transaction: t });
    }

    await t.commit();

    // emit socket
    const io = req.app.get('io');
    io.to(`canteen-${canteen_id}`).emit('order-placed', { orderId: order.id, status: 'placed' });

    res.json({ orderId: order.id, status: 'placed' });
  } catch (err) {
    await t.rollback();
    return res.status(400).json({ message: err.message });
  }
};

exports.getOrderById = async (req,res) => {
  const id = req.params.id;
  const order = await Order.findByPk(id, { include: [OrderItem] });
  if (!order) return res.status(404).json({ message: 'Not found' });
  if (order.user_id !== req.user.id && req.user.role !== 'admin' && req.user.role !== 'staff') {
    return res.status(403).json({ message: 'Forbidden' });
  }
  res.json(order);
};

exports.updateStatus = async (req,res) => {
  const { status } = req.body;
  const id = req.params.id;
  // only staff/admin can update
  if (!['preparing','ready','delivered','cancelled'].includes(status)) return res.status(400).json({ message: 'Invalid status' });
  const order = await Order.findByPk(id);
  if (!order) return res.status(404).json({ message: 'Not found' });
  if (!['admin','staff'].includes(req.user.role)) return res.status(403).json({ message: 'Forbidden' });
  order.status = status;
  await order.save();
  const io = req.app.get('io');
  io.to(`canteen-${order.canteen_id}`).emit('order-updated', { orderId: order.id, status });
  res.json({ id: order.id, status });
};
