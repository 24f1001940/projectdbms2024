const User = require('./user');
const Canteen = require('./canteen');
const Item = require('./item');
const Order = require('./order');
const OrderItem = require('./orderItem');

// Associations
Item.belongsTo(Canteen, { foreignKey: 'canteen_id' });
Canteen.hasMany(Item, { foreignKey: 'canteen_id' });

Order.belongsTo(User, { foreignKey: 'user_id' });
Order.belongsTo(Canteen, { foreignKey: 'canteen_id' });
Order.hasMany(OrderItem, { foreignKey: 'order_id' });

OrderItem.belongsTo(Item, { foreignKey: 'item_id' });
OrderItem.belongsTo(Order, { foreignKey: 'order_id' });

module.exports = {
  User,
  Canteen,
  Item,
  Order,
  OrderItem
};
