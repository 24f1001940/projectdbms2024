const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/db');
const Order = sequelize.define('order', {
  id: { type: DataTypes.INTEGER, primaryKey:true, autoIncrement:true },
  user_id: { type: DataTypes.INTEGER, allowNull:false },
  total: { type: DataTypes.DECIMAL(10,2), allowNull:false },
  status: { type: DataTypes.STRING, defaultValue:'placed' },
  canteen_id: { type: DataTypes.INTEGER, allowNull:false }
});
module.exports = Order;
