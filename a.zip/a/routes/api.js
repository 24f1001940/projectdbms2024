// routes/api.js
const express = require('express');
const router = express.Router();

const authController = require('../controllers/authController');
const orderController = require('../controllers/orderController');
const itemController = require('../controllers/itemController');

const auth = require('../middlewares/auth');

// AUTH
router.post('/auth/register', authController.register);
router.post('/auth/login', authController.login);

// CANTEENS & MENU
router.get('/canteens', itemController.listCanteens);
router.get('/canteens/:id/menu', itemController.menuByCanteen);

// ORDERS
router.post('/orders', auth, orderController.createOrder);
router.get('/orders/:id', auth, orderController.getOrderById);
router.put('/orders/:id/status', auth, orderController.updateStatus);

// ADMIN — list all orders
router.get('/admin/orders', auth, async (req, res) => {
  const { Order, OrderItem } = require('../models');
  if (req.user.role !== 'admin' && req.user.role !== 'staff') {
    return res.status(403).json({ message: "Forbidden" });
  }

  const orders = await Order.findAll({
    include: [OrderItem]
  });

  res.json(orders);
});

module.exports = router;
