require('dotenv').config();
const express = require('express');
const http = require('http');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const open = require('open');

const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// static & views (adjust if your views are EJS)
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// db init
const { sequelize } = require('./config/db');
sequelize.authenticate()
  .then(() => console.log('DB connected'))
  .catch(err => console.error('DB connection error', err));

// make io available to controllers
app.set('io', io);

// mount routes
const apiRoutes = require('./routes/api');
app.use('/api', apiRoutes);

// basic index for quick check
app.get('/', (req,res) => res.send('Canteen Management API is running'));

// sockets
io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('join-canteen', (id) => socket.join(`canteen-${id}`));
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, () => {
  console.log("===============================================");
  console.log(`🚀 Server running at:  http://localhost:${PORT}`);
  console.log("📦 Static files served from /public");
  console.log("🛠  API available at /api/*");
  console.log("===============================================");

  // Auto-open website
  open(`http://localhost:${PORT}/mainpage.html`);
});

